// index.js
const express = require('express');
const cors = require('cors');
const app = express();

// Enable JSON parsing and CORS so S3 can call this API from a different domain
app.use(express.json());
app.use(cors());

// In-memory "users" for demo (don't do this in production!)
const demoUsers = [
  { id: 1, username: 'alice', password: 'password123' },
  { id: 2, username: 'bob', password: 'mypassword' }
];

// Simple root route
app.get('/', (req, res) => {
  res.send('Hello from Elastic Beanstalk!');
});

// Basic login endpoint
app.post('/auth/login', (req, res) => {
  const { username, password } = req.body;

  // Find user in our demo array
  const user = demoUsers.find(
    (u) => u.username === username && u.password === password
  );

  if (!user) {
    return res.status(401).json({ message: 'Invalid credentials' });
  }

  // For demo, we return a "fake token" and user info
  // In real life, you’d return a JWT or session info
  const fakeToken = `fake-jwt-token-for-${user.username}`;
  res.json({
    message: 'Login successful',
    token: fakeToken,
    user: { id: user.id, username: user.username }
  });
});

// Start server on port specified by EB or fallback to 3000
const port = process.env.PORT || 3000;
app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
