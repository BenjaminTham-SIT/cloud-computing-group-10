import mysql from 'mysql2/promise';

export const handler = async (event) => {
  const dbConfig = {
    host: 'forum-database-1.ci6qmqse2nc9.us-east-1.rds.amazonaws.com', // Replace with your RDS endpoint
    user: 'admin',
    password: 'testtest',
    database: 'forum-database',
  };

  let connection;

  try {
    connection = await mysql.createConnection(dbConfig);

    if (!event.body) {
      return {
        statusCode: 400,
        body: JSON.stringify({ error: 'Missing request body' }),
      };
    }

    // Parse request body
    const { user_id, topic_id, name, content } = JSON.parse(event.body);

    // Validate required fields
    if (!user_id || !topic_id || !name || !content) {
      return {
        statusCode: 400,
        body: JSON.stringify({ error: 'Missing required fields' }),
      };
    }

    // Define the query
    const query = 'INSERT INTO posts (user_id, topic_id, name, content, createdAt) VALUES (?, ?, ?, ?, NOW())';
    const values = [user_id, topic_id, name, content];

    // Execute the query
    const [result] = await connection.execute(query, values);

    return {
      statusCode: 201,
      body: JSON.stringify({ message: 'Post created successfully', postId: result.insertId }),
    };
  } catch (error) {
    console.error('Database insertion error:', error);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: 'Failed to insert post' }),
    };
  } finally {
    if (connection) {
      await connection.end();
    }
  }
};
